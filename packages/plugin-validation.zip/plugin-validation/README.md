# @merkur/plugin-validation

`@merkur/plugin-validation` is a Merkur plugin for schema-based validation. It provides library-agnostic validation for widget props (and state in the future) that works with any schema library implementing the `safeParse()` interface, including:

- **[@esmj/schema](https://www.npmjs.com/package/@esmj/schema)**
- **[zod](https://www.npmjs.com/package/zod)**
- **[valibot](https://www.npmjs.com/package/valibot)**
- Any schema library with compatible `safeParse()` API

## Installation

```bash
npm install @merkur/plugin-validation
```

## Requirements

This plugin requires `@merkur/plugin-component` to be installed and registered before it.

## Usage

### With @esmj/schema

```javascript
import { s } from '@esmj/schema';
import { defineWidget } from '@merkur/core';
import { componentPlugin } from '@merkur/plugin-component';
import { validationPlugin } from '@merkur/plugin-validation';

const propsSchema = s.object({
  userId: s.string(),
  count: s.number().optional(),
  config: s.object({
    theme: s.string(),
  }),
});

export default defineWidget({
  name: 'my-widget',
  version: '1.0.0',
  $plugins: [
    componentPlugin,
    validationPlugin({
      props: propsSchema,
    }),
  ],
  // ... widget implementation
});
```

### With zod

```javascript
import { z } from 'zod';
import { defineWidget } from '@merkur/core';
import { componentPlugin } from '@merkur/plugin-component';
import { validationPlugin } from '@merkur/plugin-validation';

const propsSchema = z.object({
  userId: z.string(),
  count: z.number().optional(),
  config: z.object({
    theme: z.enum(['light', 'dark']),
  }),
});

export default defineWidget({
  name: 'my-widget',
  version: '1.0.0',
  $plugins: [
    componentPlugin,
    validationPlugin({
      props: propsSchema,
    }),
  ],
  // ... widget implementation
});
```

## Options

### `props` (required)

The schema object used for props validation. Must implement:

- `safeParse(value)` - Returns `{ success: boolean, data?, error? }` or `{ ok: boolean, value?, issues? }`

### `onError` (optional)

Custom error handler function. Default: `null` (throws validation error)

| Value | Description |
|-------|-------------|
| `null` | Throws the validation error (default) |
| `function` | Custom handler `(widget, result) => void` |

#### Custom error handler example

```javascript
validationPlugin({
  props: propsSchema,
  onError: (widget, result) => {
    // Send to error tracking service
    errorTracker.captureException(result.error, {
      widget: widget.name,
    });
    
    // Or log with custom formatting
    console.warn(`Widget ${widget.name} received invalid props:`, result.error);
  },
});
```

## When Validation Runs

The plugin validates props at two points:

1. **On mount** - Initial props are validated when the widget mounts
2. **On setProps** - Props are validated each time `widget.setProps()` is called

Validation is run against the **merged props** (existing props + new props), ensuring the complete props object is valid.

On successful validation, the `result.data` (transformed/coerced values) replaces the original props.

## TypeScript

Full TypeScript support is included:

```typescript
import { validationPlugin, type ValidationPluginOptions } from '@merkur/plugin-validation';
import { z } from 'zod';

const propsSchema = z.object({
  userId: z.string(),
});

type Props = z.infer<typeof propsSchema>;

const options: ValidationPluginOptions<Props> = {
  props: propsSchema,
};

export default defineWidget({
  $plugins: [
    componentPlugin,
    validationPlugin(options),
  ],
});
```

## Custom Element Integration

When using with `@merkur/integration-custom-element`, the validation plugin works seamlessly. Props passed via HTML attributes are validated after parsing:

```javascript
import { registerCustomElement } from '@merkur/integration-custom-element';
import { validationPlugin } from '@merkur/plugin-validation';
import { s } from '@esmj/schema';

const propsSchema = s.object({
  userId: s.string(),
  count: s.number(),
});

registerCustomElement({
  widgetDefinition: {
    name: 'my-widget',
    version: '1.0.0',
    $plugins: [
      componentPlugin,
      validationPlugin({ props: propsSchema }),
    ],
    // ...
  },
  observedAttributes: ['user-id', 'count'],
  attributesParser: {
    count: (value) => parseInt(value, 10),
  },
});
```

```html
<my-widget user-id="abc123" count="42"></my-widget>
```

## License

ISC
